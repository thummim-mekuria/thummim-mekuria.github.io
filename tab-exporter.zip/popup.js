document.getElementById("export").addEventListener("click", async () => {
  const status = document.getElementById("status");
  const tabs = await chrome.tabs.query({ currentWindow: true });

  const links = tabs.map((tab) => tab.url).join("\n");
  const blob = new Blob([links], { type: "text/plain" });
  const url = URL.createObjectURL(blob);

  chrome.downloads.download(
    {
      url,
      filename: "tabs.txt",
      saveAs: true,
    },
    () => {
      status.textContent = `Saved ${tabs.length} link${tabs.length === 1 ? "" : "s"}.`;
    }
  );
});
